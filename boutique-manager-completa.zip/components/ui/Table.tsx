
import React, { ReactNode } from 'react';

interface TableColumn<T> {
  header: ReactNode;
  accessor: (item: T) => ReactNode;
  className?: string;
}

interface TableProps<T> {
  columns: TableColumn<T>[];
  data: T[];
  actions?: (item: T) => ReactNode;
}

const Table = <T extends { id: string }>(
  { columns, data, actions }: TableProps<T>
) => {
  return (
    <div className="overflow-x-auto bg-card rounded-lg shadow">
      <table className="min-w-full divide-y divide-border-color">
        <thead className="bg-secondary">
          <tr>
            {columns.map((col, index) => (
              <th key={index} scope="col" className={`px-6 py-3 text-left text-xs font-medium text-text-secondary uppercase tracking-wider ${col.className}`}>
                {col.header}
              </th>
            ))}
            {actions && (
              <th scope="col" className="relative px-6 py-3">
                <span className="sr-only">Ações</span>
              </th>
            )}
          </tr>
        </thead>
        <tbody className="bg-card divide-y divide-border-color">
          {data.map((item) => (
            <tr key={item.id} className="hover:bg-background transition-colors duration-200">
              {columns.map((col, index) => (
                <td key={index} className={`px-6 py-4 whitespace-nowrap text-sm text-text-primary ${col.className}`}>
                  {col.accessor(item)}
                </td>
              ))}
              {actions && (
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                  {actions(item)}
                </td>
              )}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;