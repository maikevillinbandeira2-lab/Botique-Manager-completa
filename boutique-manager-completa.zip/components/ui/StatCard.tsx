
import React, { ReactNode } from 'react';

interface StatCardProps {
    title: string;
    value: string;
    icon: ReactNode;
    change?: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value, icon, change }) => {
    const isPositive = change && change.startsWith('+');
    const isNegative = change && change.startsWith('-');

    return (
        <div className="bg-card p-6 rounded-lg shadow-lg flex items-center space-x-4">
            <div className="bg-secondary p-3 rounded-full">
                {icon}
            </div>
            <div>
                <p className="text-sm text-text-secondary font-medium">{title}</p>
                <div className="flex items-baseline space-x-2">
                    <p className="text-2xl font-bold text-text-primary">{value}</p>
                    {change && (
                        <span className={`text-sm font-semibold ${isPositive ? 'text-green-400' : isNegative ? 'text-red-400' : 'text-text-secondary'}`}>
                            {change}
                        </span>
                    )}
                </div>
            </div>
        </div>
    );
};

export default StatCard;
