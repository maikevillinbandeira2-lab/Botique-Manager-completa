import React, { useState } from 'react';
import { Product, Customer, Sale, Seller, Exchange, Purchase, Aplicacao } from '../types';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

interface SettingsProps {
    onExport: () => void;
    onImport: (jsonData: string) => void;
    products: Product[];
    customers: Customer[];
    sales: Sale[];
    sellers: Seller[];
    exchanges: Exchange[];
    purchases: Purchase[];
    aplicacoes: Aplicacao[];
}

const Settings: React.FC<SettingsProps> = ({ onExport, onImport, products, customers, sales, sellers, exchanges, purchases, aplicacoes }) => {

    const [importFile, setImportFile] = useState<File | null>(null);
    const [emailTo, setEmailTo] = useState('');
    const [emailSubject, setEmailSubject] = useState('Relatório de Dados - BoutiqueManager');

    const escapeCsvCell = (cellData: any): string => {
        let cellString = cellData === null || cellData === undefined ? '' : String(cellData);
        if (cellString.search(/("|,|\n)/g) >= 0) {
            cellString = `"${cellString.replace(/"/g, '""')}"`;
        }
        return cellString;
    };

    const downloadCsv = (data: any[], filename: string) => {
        if (data.length === 0) {
            alert(`Não há dados para exportar em ${filename}.`);
            return;
        }
        const headers = Object.keys(data[0]);
        const csvRows = [
            headers.join(','),
            ...data.map(row => 
                headers.map(fieldName => escapeCsvCell(row[fieldName])).join(',')
            )
        ];
        
        const csvString = csvRows.join('\n');
        const blob = new Blob([`\ufeff${csvString}`], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        const today = new Date().toISOString().split('T')[0];
        a.href = url;
        a.download = `${filename.replace('.csv', '')}-${today}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    const handleExportProducts = () => {
        downloadCsv(products.map(p => ({
            ID: p.id,
            Nome: p.name,
            Descricao: p.description,
            Categoria: p.category,
            Marca: p.brand,
            Condicao: p.condition,
            Tamanho: p.size,
            Cor: p.color,
            Preco_Venda_R$: p.price,
            Preco_Compra_R$: p.purchasePrice,
            Estoque: p.quantity,
            Data_Cadastro: new Date(p.createdAt).toLocaleDateString('pt-BR'),
        })), 'produtos.csv');
    };

    const handleExportCustomers = () => {
        downloadCsv(customers.map(c => ({
            ID: c.id,
            Nome: c.name,
            Telefone: c.phone,
            Status: c.status,
            Origem: c.source,
            Origem_Outros: c.sourceOther,
            Indicado_Por: c.sourceIndicatorName,
            Data_Cadastro: new Date(c.createdAt).toLocaleDateString('pt-BR'),
        })), 'clientes.csv');
    };
    
    const handleExportSales = () => {
        const flattenedSales = sales.flatMap(sale => {
            const customer = customers.find(c => c.id === sale.customerId);
            const seller = sellers.find(s => s.id === sale.sellerId);
            return sale.items.map(item => {
                const product = products.find(p => p.id === item.productId);
                return {
                    'ID_Venda': sale.id,
                    'Data': new Date(sale.date).toLocaleString('pt-BR'),
                    'Cliente': customer?.name || 'N/A',
                    'Vendedor': sale.sellerNameOverride || seller?.name || 'N/A',
                    'ID_Produto': item.productId,
                    'Produto': product?.name || 'N/A',
                    'Quantidade': item.quantity,
                    'Preco_Unitario_R$': item.unitPrice,
                    'Total_Item_R$': (item.quantity * item.unitPrice),
                    'Total_Venda_R$': sale.total,
                    'Metodos_Pagamento': sale.payments.map(p => p.type).join(' | '),
                };
            });
        });
        downloadCsv(flattenedSales, 'vendas_detalhadas.csv');
    };

     const handleExportExchanges = () => {
        const flattenedExchanges = exchanges.flatMap(exchange => {
            const customer = customers.find(c => c.id === exchange.customerId);
            if (exchange.isBulk) {
                return [{
                    'ID_Troca': exchange.id,
                    'Data': new Date(exchange.date).toLocaleDateString('pt-BR'),
                    'Cliente': customer?.name || 'N/A',
                    'Tipo': 'Lote',
                    'Descricao_Item': '-',
                    'Valor_Item_R$': '-',
                    'Qtd_Lote': exchange.bulkQuantity,
                    'Valor_Total_R$': exchange.totalValue,
                    'Metodo_Pagamento': exchange.paymentMethod,
                    'Status_Vale': exchange.status || '-',
                    'Validade_Vale': exchange.valeExpiresAt ? new Date(exchange.valeExpiresAt).toLocaleDateString('pt-BR') : '-'
                }];
            } else {
                return exchange.items.map(item => ({
                    'ID_Troca': exchange.id,
                    'Data': new Date(exchange.date).toLocaleDateString('pt-BR'),
                    'Cliente': customer?.name || 'N/A',
                    'Tipo': 'Detalhado',
                    'Descricao_Item': item.description,
                    'Valor_Item_R$': item.purchaseValue,
                    'Qtd_Lote': '-',
                    'Valor_Total_R$': exchange.totalValue,
                    'Metodo_Pagamento': exchange.paymentMethod,
                    'Status_Vale': exchange.status || '-',
                    'Validade_Vale': exchange.valeExpiresAt ? new Date(exchange.valeExpiresAt).toLocaleDateString('pt-BR') : '-'
                }));
            }
        });
        downloadCsv(flattenedExchanges, 'trocas.csv');
    };
    
    const handleExportPurchases = () => {
        const flattenedData = purchases.flatMap(purchase => {
            const payments = purchase.payments.map(p => `${p.source === 'Outros' ? p.otherSourceName : p.source} (R$ ${p.amount.toFixed(2)})`).join(' | ');
            if (purchase.purchaseType === 'lote') {
                return [{
                    'ID_Compra': purchase.id,
                    'Data': new Date(purchase.date).toLocaleDateString('pt-BR'),
                    'Colecao': purchase.collectionName,
                    'Tipo': 'Lote',
                    'Qtd_Lote': purchase.lotInfo?.quantity || '',
                    'Descricao_Item': '-',
                    'Valor_Item_R$': '-',
                    'Valor_Total_R$': purchase.totalValue,
                    'Pagamentos': payments,
                }];
            }
            return purchase.items.map(item => ({
                'ID_Compra': purchase.id,
                'Data': new Date(purchase.date).toLocaleDateString('pt-BR'),
                'Colecao': purchase.collectionName,
                'Tipo': 'Detalhado',
                'Qtd_Lote': '-',
                'Descricao_Item': item.description,
                'Valor_Item_R$': item.purchaseValue,
                'Valor_Total_R$': purchase.totalValue,
                'Pagamentos': payments,
            }));
        });
        downloadCsv(flattenedData, 'compras.csv');
    };

    const handleExportAplicacoes = () => {
        const flattenedData = aplicacoes.flatMap(app => {
            const payments = app.payments.map(p => `${p.source === 'Outros' ? p.otherSourceName : p.source} (R$ ${p.amount.toFixed(2)})`).join(' | ');
            if (app.type === 'resumida') {
                return [{
                    'ID_Aplicacao': app.id,
                    'Data': new Date(app.date).toLocaleDateString('pt-BR'),
                    'Nome': app.name,
                    'Tipo': 'Resumida',
                    'Descricao_Item': app.summaryDescription || '-',
                    'Valor_Item_R$': '-',
                    'Valor_Total_R$': app.totalValue,
                    'Pagamentos': payments,
                }];
            }
            return app.items.map(item => ({
                'ID_Aplicacao': app.id,
                'Data': new Date(app.date).toLocaleDateString('pt-BR'),
                'Nome': app.name,
                'Tipo': 'Detalhada',
                'Descricao_Item': item.description,
                'Valor_Item_R$': item.value,
                'Valor_Total_R$': app.totalValue,
                'Pagamentos': payments,
            }));
        });
        downloadCsv(flattenedData, 'aplicacoes.csv');
    };

    const generatePdf = (
        title: string, 
        columns: string[], 
        rows: (string | number)[][], 
        summaryText: string, 
        fileName: string,
        columnStyles: any = {}
    ) => {
        if (rows.length === 0) {
            alert(`Não há dados para gerar o relatório "${title}".`);
            return;
        }
        const doc = new jsPDF();
        const today = new Date().toLocaleDateString('pt-BR');
        const theme = document.body.className;
        const headColor = theme === 'theme-dark-emerald' ? [16, 185, 129] : [77, 124, 15];

        // Header
        doc.setFontSize(18);
        doc.text(`${title} - BoutiqueManager`, 14, 22);
        doc.setFontSize(11);
        doc.setTextColor(100);
        doc.text(`Gerado em: ${today}`, 14, 30);

        // Table
        autoTable(doc, {
            head: [columns],
            body: rows,
            startY: 35,
            theme: 'grid',
            headStyles: { fillColor: headColor, textColor: [255, 255, 255], fontStyle: 'bold' },
            columnStyles: columnStyles,
            didDrawPage: (data) => {
                const pageCount = doc.getNumberOfPages();
                doc.setFontSize(10);
                doc.text(`Página ${data.pageNumber} de ${pageCount}`, data.settings.margin.left, doc.internal.pageSize.height - 10);
            }
        });

        // Summary
        const finalY = (doc as any).lastAutoTable.finalY;
        if (finalY) { // Check if finalY is defined
             doc.setFontSize(12);
            doc.setFont('helvetica', 'bold');
            doc.text(summaryText, 14, finalY + 15);
        }
       
        // Save
        doc.save(`${fileName}_${new Date().toISOString().split('T')[0]}.pdf`);
    };

    const handleExportSalesPdf = () => {
        const tableColumn = ["Data", "Cliente", "Vendedor", "Itens", "Total"];
        const tableRows = sales.map(sale => {
            const customer = customers.find(c => c.id === sale.customerId);
            const seller = sellers.find(s => s.id === sale.sellerId);
            const itemsString = sale.items.map(item => {
                const product = products.find(p => p.id === item.productId);
                return `${item.quantity}x ${product ? product.name : 'N/A'} (R$ ${item.unitPrice.toFixed(2)})`;
            }).join('\n');

            return [
                new Date(sale.date).toLocaleDateString('pt-BR'),
                customer ? customer.name : 'N/A',
                sale.sellerNameOverride || (seller ? seller.name : 'N/A'),
                itemsString,
                `R$ ${sale.total.toFixed(2)}`
            ];
        });
        const totalRevenue = sales.reduce((sum, sale) => sum + sale.total, 0);
        generatePdf(
            "Relatório de Vendas",
            tableColumn,
            tableRows,
            `Total Arrecadado: R$ ${totalRevenue.toFixed(2)}`,
            'relatorio_vendas',
            { 3: { cellWidth: 'auto' } }
        );
    };

    const handleExportProductsPdf = () => {
        const tableColumn = ['Nome', 'Marca', 'Estoque', 'Preço Compra', 'Preço Venda'];
        const tableRows = products.map(p => [
            p.name,
            p.brand,
            p.quantity,
            `R$ ${p.purchasePrice.toFixed(2)}`,
            `R$ ${p.price.toFixed(2)}`
        ]);
        const totalStockValue = products.reduce((sum, p) => sum + (p.price * p.quantity), 0);
        generatePdf(
            "Relatório de Produtos",
            tableColumn,
            tableRows,
            `Total de Produtos: ${products.length} | Valor em Estoque (Venda): R$ ${totalStockValue.toFixed(2)}`,
            'relatorio_produtos'
        );
    };

    const handleExportCustomersPdf = () => {
        const tableColumn = ['Nome', 'Telefone', 'Status', 'Origem', 'Data Cadastro'];
        const tableRows = customers.map(c => [
            c.name,
            c.phone || '-',
            c.status,
            c.source === 'Outros' && c.sourceOther ? c.sourceOther : (c.source === 'Indicação' && c.sourceIndicatorName ? `${c.source} (${c.sourceIndicatorName})` : c.source),
            new Date(c.createdAt).toLocaleDateString('pt-BR')
        ]);
        generatePdf(
            "Relatório de Clientes",
            tableColumn,
            tableRows,
            `Total de Clientes: ${customers.length}`,
            'relatorio_clientes'
        );
    };
    
    const handleExportExchangesPdf = () => {
        const tableColumn = ['Data', 'Cliente', 'Tipo', 'Detalhes', 'Valor'];
        const tableRows = exchanges.map(ex => {
            const customer = customers.find(c => c.id === ex.customerId)?.name || 'N/A';
            const details = ex.isBulk
                ? `Lote de ${ex.bulkQuantity} peças`
                : ex.items.map(i => `${i.description} (R$ ${i.purchaseValue.toFixed(2)})`).join('\n');
            return [
                new Date(ex.date).toLocaleDateString('pt-BR'),
                customer,
                ex.paymentMethod,
                details,
                `R$ ${ex.totalValue.toFixed(2)}`
            ];
        });
        const totalValue = exchanges.reduce((sum, ex) => sum + ex.totalValue, 0);
        generatePdf(
            "Relatório de Trocas",
            tableColumn,
            tableRows,
            `Valor Total em Trocas: R$ ${totalValue.toFixed(2)}`,
            'relatorio_trocas'
        );
    };

    const handleExportPurchasesPdf = () => {
        const tableColumn = ['Data', 'Coleção', 'Tipo', 'Pagamentos', 'Valor Total'];
        const tableRows = purchases.map(p => {
            const paymentsString = p.payments.map(pay => `${pay.source === 'Outros' ? (pay.otherSourceName || 'Outros') : pay.source} (R$ ${pay.amount.toFixed(2)})`).join('\n');
            return [
                new Date(p.date).toLocaleDateString('pt-BR'),
                p.collectionName,
                p.purchaseType === 'detalhado' ? 'Detalhado' : 'Lote',
                paymentsString,
                `R$ ${p.totalValue.toFixed(2)}`
            ];
        });
        const totalValue = purchases.reduce((sum, p) => sum + p.totalValue, 0);
        generatePdf(
            "Relatório de Compras",
            tableColumn,
            tableRows,
            `Valor Total em Compras: R$ ${totalValue.toFixed(2)}`,
            'relatorio_compras'
        );
    };

    const handleExportAplicacoesPdf = () => {
        const tableColumn = ['Data', 'Nome', 'Tipo', 'Pagamentos', 'Valor Total'];
        const tableRows = aplicacoes.map(app => {
            const paymentsString = app.payments.map(pay => `${pay.source === 'Outros' ? (pay.otherSourceName || 'Outros') : pay.source} (R$ ${pay.amount.toFixed(2)})`).join('\n');
            return [
                new Date(app.date).toLocaleDateString('pt-BR'),
                app.name,
                app.type === 'detalhada' ? 'Detalhada' : 'Resumida',
                paymentsString,
                `R$ ${app.totalValue.toFixed(2)}`
            ];
        });
        const totalValue = aplicacoes.reduce((sum, app) => sum + app.totalValue, 0);
        generatePdf(
            "Relatório de Aplicações",
            tableColumn,
            tableRows,
            `Valor Total em Aplicações: R$ ${totalValue.toFixed(2)}`,
            'relatorio_aplicacoes'
        );
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files.length > 0) {
            setImportFile(e.target.files[0]);
        }
    };

    const handleImportClick = () => {
        if (!importFile) {
            alert("Por favor, selecione um arquivo de backup para importar.");
            return;
        }

        const confirmation = window.confirm(
            "ATENÇÃO!\n\nA importação de um backup substituirá TODOS os dados atuais do aplicativo. Esta ação não pode ser desfeita.\n\nRecomenda-se exportar um backup dos dados atuais antes de prosseguir.\n\nDeseja continuar com a importação?"
        );

        if (confirmation) {
            const reader = new FileReader();
            reader.onload = (event) => {
                const result = event.target?.result;
                if (typeof result === 'string') {
                    onImport(result);
                }
            };
            reader.readAsText(importFile);
        }
    };
    
    const handleOpenMail = (e: React.FormEvent) => {
        e.preventDefault();
        const body = "Olá,\n\nSegue em anexo o relatório de dados exportado do sistema BoutiqueManager.\n\n(Lembre-se de anexar os arquivos CSV baixados aqui.)\n\nAtenciosamente,";
        const mailtoLink = `mailto:${emailTo}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(body)}`;
        window.location.href = mailtoLink;
    };

    return (
        <div className="space-y-8 max-w-4xl mx-auto">
            <h1 className="text-4xl font-bold text-text-primary">Configurações</h1>

             <div className="bg-card p-6 rounded-lg shadow-lg">
                 <h2 className="text-2xl font-semibold text-text-primary border-b border-border-color pb-3 mb-4">Exportar Relatórios (PDF)</h2>
                 <p className="text-text-secondary mb-6">
                    Gere relatórios formatados em PDF, ideais para impressão e compartilhamento.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <button onClick={handleExportSalesPdf} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Vendas</button>
                    <button onClick={handleExportProductsPdf} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Produtos</button>
                    <button onClick={handleExportCustomersPdf} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Clientes</button>
                    <button onClick={handleExportExchangesPdf} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Trocas</button>
                    <button onClick={handleExportPurchasesPdf} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Compras</button>
                    <button onClick={handleExportAplicacoesPdf} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Aplicações</button>
                </div>
            </div>

            <div className="bg-card p-6 rounded-lg shadow-lg">
                 <h2 className="text-2xl font-semibold text-text-primary border-b border-border-color pb-3 mb-4">Exportar Relatórios (Planilha)</h2>
                 <p className="text-text-secondary mb-6">
                    Gere relatórios em formato de planilha (CSV) para análise externa ou para enviar por e-mail. 
                    Clique em um botão para baixar o arquivo correspondente, que pode ser aberto no Excel ou Google Sheets.
                </p>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                    <button onClick={handleExportProducts} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Produtos</button>
                    <button onClick={handleExportCustomers} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Clientes</button>
                    <button onClick={handleExportSales} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Vendas</button>
                    <button onClick={handleExportExchanges} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Trocas</button>
                    <button onClick={handleExportPurchases} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Compras</button>
                    <button onClick={handleExportAplicacoes} className="p-4 rounded-lg bg-secondary text-text-primary hover:bg-opacity-80 transition-colors text-center">Aplicações</button>
                </div>
            </div>

            <div className="bg-card p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-semibold text-text-primary border-b border-border-color pb-3 mb-4">Enviar Relatório por E-mail</h2>
                <p className="text-text-secondary mb-4">
                    Esta função abrirá seu aplicativo de e-mail padrão.
                </p>
                <div className="bg-yellow-500/10 text-yellow-300 p-3 rounded-md text-sm mb-4">
                    <p className="font-bold">Importante:</p>
                    <p>Você precisará anexar os arquivos CSV (baixados na seção acima) <span className="font-bold">manualmente</span> ao e-mail.</p>
                </div>
                 <form onSubmit={handleOpenMail} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label className="block text-sm font-medium text-text-secondary mb-1">Destinatário (E-mail)</label>
                             <input 
                                type="email"
                                value={emailTo}
                                onChange={(e) => setEmailTo(e.target.value)}
                                placeholder="email@exemplo.com"
                                className="w-full bg-input-bg text-text-primary p-2 rounded border border-border-color"
                             />
                        </div>
                         <div>
                            <label className="block text-sm font-medium text-text-secondary mb-1">Assunto</label>
                             <input 
                                type="text"
                                value={emailSubject}
                                onChange={(e) => setEmailSubject(e.target.value)}
                                className="w-full bg-input-bg text-text-primary p-2 rounded border border-border-color"
                             />
                        </div>
                    </div>
                    <div className="flex justify-end">
                        <button
                            type="submit"
                            className="px-5 py-2 rounded-lg bg-primary hover:bg-accent text-white font-semibold transition-colors shadow-md"
                        >
                            Abrir E-mail
                        </button>
                    </div>
                </form>
            </div>

            <div className="bg-card p-6 rounded-lg shadow-lg">
                <h2 className="text-2xl font-semibold text-text-primary border-b border-border-color pb-3 mb-4">Backup e Restauração (Técnico)</h2>
                <p className="text-text-secondary mb-6">
                    Use esta seção para criar um backup completo de todos os dados do sistema em um arquivo técnico (.json).
                    Este arquivo é usado exclusivamente para restaurar os dados neste mesmo aplicativo.
                </p>

                <div className="space-y-8">
                    {/* Export Section */}
                    <div className="bg-background p-4 rounded-md border border-border-color">
                        <h3 className="text-lg font-medium text-text-primary mb-2">Exportar Backup Técnico (JSON)</h3>
                        <p className="text-sm text-text-secondary mb-4">
                            Clique no botão abaixo para baixar um arquivo (.json) contendo todos os dados da sua loja.
                            Guarde este arquivo em um local seguro.
                        </p>
                        <button
                            onClick={onExport}
                            className="px-5 py-2 rounded-lg bg-primary hover:bg-accent text-white font-semibold transition-colors shadow-md"
                        >
                            Exportar Todos os Dados
                        </button>
                    </div>

                    {/* Import Section */}
                    <div className="bg-background p-4 rounded-md border-2 border-red-500/50">
                        <h3 className="text-lg font-medium text-text-primary mb-2">Importar Backup Técnico (JSON)</h3>
                         <div className="bg-red-500/10 text-red-300 p-3 rounded-md text-sm mb-4">
                            <p className="font-bold">Atenção: Ação Irreversível!</p>
                            <p>Importar um arquivo de backup substituirá <span className="font-bold">TODOS</span> os dados existentes no aplicativo. Faça um backup dos dados atuais antes de prosseguir.</p>
                        </div>
                        <div className="flex flex-col sm:flex-row items-center gap-4">
                             <input 
                                type="file"
                                accept=".json"
                                onChange={handleFileChange}
                                className="flex-grow w-full text-sm text-text-secondary file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-primary file:text-white hover:file:bg-accent cursor-pointer"
                             />
                            <button
                                onClick={handleImportClick}
                                disabled={!importFile}
                                className="w-full sm:w-auto px-5 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white font-semibold transition-colors shadow-md disabled:bg-gray-500 disabled:cursor-not-allowed"
                            >
                                Importar e Substituir Dados
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Settings;